# SNIPES for Samsung Android — starter project

A native Android starter for a Samsung phone, designed for **both voice and touch control**.

## Included in this version
- Futuristic blue SNIPES interface
- Type commands or tap the microphone to speak
- Spoken responses using Android Text-to-Speech
- Offline phone actions:
  - `call 0712345678` opens the phone dialer
  - `call a contact` opens the contact picker, then the dialer
  - `message 0712345678` opens the SMS app
  - `open camera`
  - `set alarm for 7:30 AM`
  - `open Wi-Fi settings`
  - `open Bluetooth settings`
  - `open settings`, `time`, `date`, `help`
- GitHub Actions workflow to build a debug APK

## Important safety and Android limits
- SNIPES does not place calls or send texts silently. It opens Samsung's dialer or messaging app so the user can review and confirm.
- No phone-call, SMS, or contacts permission is requested. The Android contact picker is used when choosing a contact.
- Microphone permission is requested only when the microphone button is tapped.
- Android and Samsung One UI decide which settings can be changed by third-party apps. SNIPES opens the relevant settings screen instead of bypassing system controls.
- Always-listening wake phrase is not included. Tap the microphone to start speech recognition.
- Online AI is not connected yet. A secure backend is needed; never put private API keys in the APK.
- Infobip AgentOS is not connected yet and would need a separately configured server-side integration.

## Build on GitHub using your Android phone
1. Create a GitHub repository named `snipes-android`.
2. Extract this ZIP on your phone.
3. Upload the **contents** of the extracted `SNIPES-Samsung-Android` folder to the repository root (not just the ZIP file).
4. Open the repository's **Actions** tab. Enable workflows if GitHub asks.
5. Run **Build SNIPES APK**, or push a commit to the `main` branch.
6. Open the completed workflow and download the `snipes-samsung-debug-apk` artifact.
7. Extract the artifact ZIP and install `app-debug.apk`. Android may ask you to allow installation from the app used to download it.

## Technical details
- Kotlin + Jetpack Compose
- Minimum Android version: Android 6.0 (API 23)
- Target SDK: 35
- Java 17 / Gradle 8.9
