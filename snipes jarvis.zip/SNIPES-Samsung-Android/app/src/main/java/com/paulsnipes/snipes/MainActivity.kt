package com.paulsnipes.snipes

import android.Manifest
import android.content.ActivityNotFoundException
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.provider.AlarmClock
import android.provider.ContactsContract
import android.speech.RecognizerIntent
import android.speech.tts.TextToSpeech
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

private val Navy = Color(0xFF071426)
private val Panel = Color(0xFF10243B)
private val Cyan = Color(0xFF43D9FF)

class MainActivity : ComponentActivity() {
    private var tts: TextToSpeech? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        tts = TextToSpeech(this) { status ->
            if (status == TextToSpeech.SUCCESS) {
                tts?.language = Locale.UK
                tts?.setSpeechRate(0.94f)
            }
        }
        setContent { SnipesScreen(::speak) }
    }

    private fun speak(message: String) {
        tts?.speak(message, TextToSpeech.QUEUE_FLUSH, null, "snipes_reply")
    }

    override fun onDestroy() {
        tts?.stop()
        tts?.shutdown()
        super.onDestroy()
    }
}

@Composable
private fun SnipesScreen(speak: (String) -> Unit) {
    val context = LocalContext.current
    var transcript by remember { mutableStateOf("Good day, Sir. SNIPES is ready. You can type or tap the microphone.") }
    var command by remember { mutableStateOf("") }

    val contactPicker = rememberLauncherForActivityResult(
        ActivityResultContracts.StartActivityForResult()
    ) { result ->
        val uri = result.data?.data
        if (uri != null) {
            try {
                val cursor = context.contentResolver.query(
                    uri,
                    arrayOf(ContactsContract.CommonDataKinds.Phone.NUMBER),
                    null, null, null
                )
                val number = cursor?.use {
                    if (it.moveToFirst()) it.getString(0) else null
                }
                if (!number.isNullOrBlank()) {
                    context.startActivity(Intent(Intent.ACTION_DIAL, Uri.parse("tel:${Uri.encode(number)}")))
                    transcript = "Opening the phone dialer for the selected contact. Please review and tap Call."
                } else {
                    transcript = "I couldn't find a phone number for that contact."
                }
            } catch (_: Exception) {
                transcript = "I couldn't read that contact. Please try again."
            }
        }
    }

    val speechLauncher = rememberLauncherForActivityResult(
        ActivityResultContracts.StartActivityForResult()
    ) { result ->
        val spoken = result.data?.getStringArrayListExtra(RecognizerIntent.EXTRA_RESULTS)?.firstOrNull()
        if (!spoken.isNullOrBlank()) {
            command = spoken
            transcript = handleCommand(spoken, context) {
                contactPicker.launch(Intent(Intent.ACTION_PICK, ContactsContract.CommonDataKinds.Phone.CONTENT_URI))
            }
            speak(transcript)
        }
    }

    val permissionLauncher = rememberLauncherForActivityResult(
        ActivityResultContracts.RequestPermission()
    ) { granted ->
        if (granted) {
            try {
                val intent = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
                    putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
                    putExtra(RecognizerIntent.EXTRA_LANGUAGE, Locale.getDefault())
                    putExtra(RecognizerIntent.EXTRA_PROMPT, "Speak to SNIPES")
                }
                speechLauncher.launch(intent)
            } catch (_: ActivityNotFoundException) {
                transcript = "Speech recognition isn't available. You can still type commands."
            }
        } else {
            transcript = "Microphone permission was not granted. You can still type commands."
        }
    }

    MaterialTheme(colorScheme = darkColorScheme(
        primary = Cyan, background = Navy, surface = Panel, onSurface = Color.White
    )) {
        Box(
            Modifier.fillMaxSize().background(
                Brush.verticalGradient(listOf(Color(0xFF0B2340), Navy, Color(0xFF030914)))
            )
        ) {
            Column(
                Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(22.dp),
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically) {
                    Column {
                        Text("PERSONAL ASSISTANT", color = Cyan, fontSize = 10.sp, letterSpacing = 2.sp)
                        Text("SNIPES", color = Color.White, fontSize = 27.sp, fontWeight = FontWeight.Bold)
                    }
                    Text("SAMSUNG", color = Color.LightGray, fontSize = 11.sp)
                }

                Spacer(Modifier.height(28.dp))
                Box(
                    Modifier.size(190.dp).background(
                        Brush.radialGradient(listOf(Color(0xFF1B7192), Color(0xFF103454), Color.Transparent)),
                        CircleShape
                    ),
                    contentAlignment = Alignment.Center
                ) {
                    Box(Modifier.size(136.dp).background(Color(0xFF0C2945), CircleShape),
                        contentAlignment = Alignment.Center) {
                        Text("S", color = Cyan, fontSize = 82.sp, fontWeight = FontWeight.Light)
                    }
                }
                Spacer(Modifier.height(14.dp))
                Text("SYSTEM READY", color = Cyan, fontSize = 12.sp, letterSpacing = 3.sp)
                Text("Voice control + touch control", color = Color.LightGray, fontSize = 13.sp)

                Spacer(Modifier.height(22.dp))
                Card(colors = CardDefaults.cardColors(containerColor = Panel),
                    shape = RoundedCornerShape(18.dp), modifier = Modifier.fillMaxWidth()) {
                    Column(Modifier.padding(18.dp)) {
                        Text("SNIPES", color = Cyan, fontSize = 11.sp, letterSpacing = 2.sp)
                        Spacer(Modifier.height(8.dp))
                        Text(transcript, color = Color.White, fontSize = 16.sp)
                    }
                }

                Spacer(Modifier.height(14.dp))
                OutlinedTextField(
                    value = command, onValueChange = { command = it },
                    modifier = Modifier.fillMaxWidth(),
                    label = { Text("Type a command") },
                    placeholder = { Text("e.g. call 0712345678") },
                    singleLine = true,
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedBorderColor = Cyan, unfocusedBorderColor = Color(0xFF42617A),
                        focusedLabelColor = Cyan, unfocusedLabelColor = Color.LightGray,
                        focusedTextColor = Color.White, unfocusedTextColor = Color.White,
                        cursorColor = Cyan
                    )
                )
                Spacer(Modifier.height(10.dp))
                Button(
                    onClick = {
                        if (command.isNotBlank()) {
                            transcript = handleCommand(command, context) {
                                contactPicker.launch(Intent(Intent.ACTION_PICK, ContactsContract.CommonDataKinds.Phone.CONTENT_URI))
                            }
                            speak(transcript)
                        }
                    },
                    modifier = Modifier.fillMaxWidth(),
                    colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF087CA5))
                ) { Text("RUN COMMAND", color = Color.White) }

                Spacer(Modifier.height(12.dp))
                Button(
                    onClick = { permissionLauncher.launch(Manifest.permission.RECORD_AUDIO) },
                    modifier = Modifier.size(76.dp),
                    shape = CircleShape,
                    colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF0B789E))
                ) { Text("MIC", color = Color.White, fontWeight = FontWeight.Bold) }
                Text("Tap to speak to SNIPES", color = Color.LightGray, fontSize = 12.sp)

                Spacer(Modifier.height(22.dp))
                Text("TRY THESE COMMANDS", color = Cyan, fontSize = 11.sp, letterSpacing = 2.sp)
                Spacer(Modifier.height(8.dp))
                Text(
                    "• Call 0712345678 or call a contact\n" +
                    "• Send message to 0712345678\n" +
                    "• Open camera\n• Set alarm for 7:30 AM\n" +
                    "• Open Wi-Fi settings / Bluetooth settings\n" +
                    "• Open settings / What time is it? / Help",
                    color = Color(0xFFB9D0E0), fontSize = 13.sp, lineHeight = 21.sp
                )
                Spacer(Modifier.height(18.dp))
                Text(
                    "Calls open the dialer for your review. Messages open the SMS app for you to review and send. Android controls permissions and available actions.",
                    color = Color(0xFF8EAFC5), fontSize = 10.sp, lineHeight = 15.sp
                )
                Spacer(Modifier.height(8.dp))
                Text(
                    "Wake-word listening and online AI are not connected in this starter version.",
                    color = Color(0xFF8EAFC5), fontSize = 10.sp
                )
            }
        }
    }
}

private fun handleCommand(raw: String, context: android.content.Context, pickContact: () -> Unit): String {
    val text = raw.lowercase(Locale.getDefault()).trim()
    fun launch(intent: Intent, success: String): String {
        return try {
            intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            context.startActivity(intent)
            success
        } catch (_: Exception) {
            "That feature isn't available on this phone."
        }
    }

    val digits = Regex("""(?:\+?\d[\d\s()-]{6,}\d)""").find(raw)?.value
        ?.replace(Regex("""[^\d+]"""), "")

    return when {
        text.contains("time") -> "The time is " + SimpleDateFormat("h:mm a", Locale.getDefault()).format(Date())
        text.contains("date") || text.contains("today") ->
            "Today is " + SimpleDateFormat("EEEE, d MMMM yyyy", Locale.getDefault()).format(Date())
        text == "help" || text.contains("what can you do") ->
            "I can open the dialer, help you choose a contact, open the SMS app, camera, alarm screen, Wi-Fi, Bluetooth and Android settings. Try saying call followed by a number."
        text.startsWith("call ") || text.startsWith("phone ") || text.startsWith("dial ") -> {
            if (digits != null && digits.length >= 7) {
                launch(Intent(Intent.ACTION_DIAL, Uri.parse("tel:${Uri.encode(digits)}")),
                    "Opening the dialer. Check the number and tap Call when you're ready.")
            } else {
                pickContact()
                "Choose a contact. I'll open the dialer so you can review the number before calling."
            }
        }
        text.startsWith("message ") || text.startsWith("text ") || text.startsWith("sms ") -> {
            if (digits != null && digits.length >= 7) {
                launch(Intent(Intent.ACTION_SENDTO, Uri.parse("smsto:${Uri.encode(digits)}")),
                    "Opening your messaging app. Write your message and tap Send when ready.")
            } else {
                "Please say: message followed by the phone number."
            }
        }
        text.contains("camera") || text.contains("take a photo") ->
            launch(Intent("android.media.action.IMAGE_CAPTURE"), "Opening the camera.")
        text.contains("alarm") -> {
            val match = Regex("""(\d{1,2})(?::(\d{2}))?\s*(am|pm)?""", RegexOption.IGNORE_CASE).find(text)
            if (match != null) {
                var hour = match.groupValues[1].toIntOrNull() ?: 7
                val minute = match.groupValues[2].toIntOrNull() ?: 0
                val suffix = match.groupValues[3].lowercase()
                if (suffix == "pm" && hour < 12) hour += 12
                if (suffix == "am" && hour == 12) hour = 0
                if (hour in 0..23 && minute in 0..59) {
                    launch(Intent(AlarmClock.ACTION_SET_ALARM).apply {
                        putExtra(AlarmClock.EXTRA_HOUR, hour)
                        putExtra(AlarmClock.EXTRA_MINUTES, minute)
                        putExtra(AlarmClock.EXTRA_MESSAGE, "SNIPES reminder")
                        putExtra(AlarmClock.EXTRA_SKIP_UI, false)
                    }, "Opening the alarm screen for ${match.value}. Review and save the alarm.")
                } else "Please give a valid time, like 7:30 AM."
            } else "Say a time, for example: set alarm for 7:30 AM."
        }
        text.contains("wi-fi") || text.contains("wifi") ->
            launch(Intent(android.provider.Settings.ACTION_WIFI_SETTINGS), "Opening Wi-Fi settings.")
        text.contains("bluetooth") ->
            launch(Intent(android.provider.Settings.ACTION_BLUETOOTH_SETTINGS), "Opening Bluetooth settings.")
        text.contains("settings") ->
            launch(Intent(android.provider.Settings.ACTION_SETTINGS), "Opening Android settings.")
        text.contains("hello") || text.contains("hi snipes") ->
            "Hello, Sir. SNIPES is ready. What would you like me to do?"
        else -> "I heard: $raw. Try Help to see the commands available in this starter version."
    }
}
